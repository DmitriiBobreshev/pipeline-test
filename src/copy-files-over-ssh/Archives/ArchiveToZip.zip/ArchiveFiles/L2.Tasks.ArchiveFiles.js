"use strict";
var chai = require("chai"),
    assert = chai.assert,
    expect = chai.expect;
var fs = require('fs');

chai.should();
describe("L2.Tasks.ArchiveFiles.", function() {

    beforeEach(function() {
    });

    it("ArchiveToZip", function() {
        let filePath = "ArchiveToZip.zip";
        assert.isTrue(fs.existsSync(filePath), "Archive file not found: " + filePath);
        assert.isTrue(fs.statSync(filePath).size > 0, "Archive file size is 0");
    });

    it("ArchiveTo7z", function() {
        let filePath = "ArchiveTo7z.7z";
        assert.isTrue(fs.existsSync(filePath), "Archive file not found: " + filePath);
        assert.isTrue(fs.statSync(filePath).size > 0, "Archive file size is 0");
    });

    it("ArchiveToTar", function() {
        let filePath = "ArchiveToTar.tar";
        assert.isTrue(fs.existsSync(filePath), "Archive file not found: " + filePath);
        assert.isTrue(fs.statSync(filePath).size > 0, "Archive file size is 0");
    });

    it("ArchiveToTarGz", function() {
        let filePath = "ArchiveToTarGz.tar.gz";
        assert.isTrue(fs.existsSync(filePath), "Archive file not found: " + filePath);
        assert.isTrue(fs.statSync(filePath).size > 0, "Archive file size is 0");
    });

    it("ArchiveToTarBz2", function() {
        let filePath = "ArchiveToTarBz2.tar.bz2";
        assert.isTrue(fs.existsSync(filePath), "Archive file not found: " + filePath);
        assert.isTrue(fs.statSync(filePath).size > 0, "Archive file size is 0");
    });

    it("ArchiveToTarXz", function() {
        let filePath = "ArchiveToTarXz.tar.xz";
        assert.isTrue(fs.existsSync(filePath), "Archive file not found: " + filePath);
        assert.isTrue(fs.statSync(filePath).size > 0, "Archive file size is 0");
    });

    it("ArchiveToWim", function() {
        let filePath = "ArchiveToWim.wim";
        assert.isTrue(fs.existsSync(filePath), "Archive file not found: " + filePath);
        assert.isTrue(fs.statSync(filePath).size > 0, "Archive file size is 0");
    });

    it("ArchiveToZipNonStandardName", function() {
        let filePath = "ArchiveToZipNonStandard.abc";
        assert.isTrue(fs.existsSync(filePath), "Archive file not found: " + filePath);
        assert.isTrue(fs.statSync(filePath).size > 0, "Archive file size is 0");
    });

    it("ArchiveInNewFolder", function() {
        let filePath = "NewFolder/ArchiveInNewFolder.zip";
        assert.isTrue(fs.existsSync(filePath), "Archive file not found: " + filePath);
        assert.isTrue(fs.statSync(filePath).size > 0, "Archive file size is 0");
    });

    it("ArchiveWithNoRootFolder", function() {
        let filePath = "ArchiveWithNoRootFolder.zip";
        assert.isTrue(fs.existsSync(filePath), "Archive file not found: " + filePath);
        assert.isTrue(fs.statSync(filePath).size > 0, "Archive file size is 0");
    });
});
