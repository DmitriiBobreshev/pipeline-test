'use strict';
var gulp  = require('gulp');
var mocha = require('gulp-mocha');
var argv = require('yargs').argv;

// Report test results as a list by default.
// Build definitions can pass 'reporter=junit' to create JUnit results files.
var reporterUnitTest = { reporter: 'list' };
if (argv.reporter === "junit") {
    reporterUnitTest = { reporter: 'mocha-junit-reporter', reporterOptions: { captureConsole: true, mochaFile: 'test-results.xml'} } ;
}

function errorHandler(err) {
    console.error(err.message);
    process.exit(1);
}

gulp.task('default', ['test']);
gulp.task('test', function() {
    return gulp.src(['L2.*.js'], {read: false})
    .pipe(mocha(reporterUnitTest))
    .on('error', errorHandler);
});